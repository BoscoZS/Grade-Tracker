let classCount = 0;
let mode = 'student';
let students = [];
let selectedStudent = null;

function setMode(selectedMode) {
  document.getElementById('student-add-class').style.display = selectedMode === 'student' ? 'block' : 'none';
  mode = selectedMode;
  document.getElementById('teacher-section').style.display = mode === 'teacher' ? 'block' : 'none';
  document.getElementById('classes-container').innerHTML = '';
  selectedStudent = null;
  document.getElementById('student-add-class').style.display = mode === 'student' ? 'block' : 'none';
  

  if (mode === 'teacher') {
    students.forEach((student, index) => {
      const option = document.createElement('option');
      option.value = index;
      option.textContent = student.name;
      studentSelect.appendChild(option);
    });
    document.getElementById('global-add-class').style.display = 'block';
    renderStudentList();
    document.getElementById('student-add-class').style.display = 'none';
  } else {
    document.getElementById('student-add-class').style.display = 'block';
document.getElementById('teacher-section').style.display = 'none';
  }
}

function addStudent() {
  const name = document.getElementById('student-name').value.trim();
  if (!name || students.some(s => s.name === name)) return;
  students.push({ name, classes: [] });
  document.getElementById('student-name').value = '';
  renderStudentList();
  saveData();
}
  saveData();


function renderStudentList() {
  const list = document.getElementById('student-list');
  list.innerHTML = '';
  students.forEach((student, index) => {
    const li = document.createElement('li');

    const nameSpan = document.createElement('span');
    nameSpan.textContent = student.name;
    nameSpan.style.cursor = 'pointer';
    nameSpan.onclick = () => {
      if (selectedStudent === index) {
        selectedStudent = null;
        document.getElementById('classes-container').innerHTML = '';
      } else {
        selectedStudent = index;
        document.getElementById('classes-container').innerHTML = '';

        const addClassButton = document.createElement('button');
        addClassButton.textContent = `Add Class for ${students[index].name}`;
        addClassButton.className = 'add-btn';
        addClassButton.onclick = () => addClassSection();
        document.getElementById('classes-container').appendChild(addClassButton);

        students[index].classes.forEach(cls => addClassSection(cls));
      }
    };

    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = '❌';
    deleteBtn.onclick = (e) => {
      e.stopPropagation();
      deleteStudent(index);
    };

    li.appendChild(nameSpan);
    li.appendChild(deleteBtn);
    list.appendChild(li);
  });
  }

function deleteStudent(index) {
  students.splice(index, 1);
  renderStudentList();
  document.getElementById('classes-container').innerHTML = '';
  saveData();
}

function showStudentClasses(index) {
  if (selectedStudent === index) {
    selectedStudent = null;
    document.getElementById('classes-container').innerHTML = '';
    document.querySelector('.add-btn-container').style.display = 'none';
    return;
  }
  selectedStudent = index;
  document.getElementById('classes-container').innerHTML = '';

  const addClassButton = document.createElement('button');
  addClassButton.textContent = `Add Class for ${students[index].name}`;
  addClassButton.className = 'add-btn';
  addClassButton.onclick = () => addClassSection();
  document.getElementById('classes-container').appendChild(addClassButton);

  students[index].classes.forEach(cls => addClassSection(cls));
}

function addClassSection(data = null) {
  const container = document.getElementById('classes-container');
  const section = document.createElement('div');
  section.classList.add('class-section');
  section.dataset.index = classCount;

  section.innerHTML = `
    <button class="close-btn" onclick="this.closest('.class-section').remove(); saveData();">×</button>
    <label><strong>Class Title:</strong>
      <input type="text" class="class-title" placeholder="Enter class title" value="${data?.title || ''}" oninput="saveData()" />
    </label><br><br>
    <h2 contenteditable="true" oninput="saveData()">Class ${classCount + 1} (Click to edit)</h2>
    <table>
      <thead>
        <tr>
          <th>Exam Title</th>
          <th>Grade</th>
          <th>Grade Type</th>
          <th>Out Of</th>
          <th>Weight (%)</th>
        </tr>
      </thead>
      <tbody id="class-${classCount}-table">
        ${(data?.exams || [createExamRow(classCount)]).join('')}
      </tbody>
    </table>
    <button onclick="addExamRow(${classCount})">+ Add Exam</button>
    <p><strong>Final Average:</strong> <span id="average-${classCount}">0</span>%</p>
  `;

  container.appendChild(section);
  if (mode === 'teacher' && selectedStudent !== null && !data) {
    students[selectedStudent].classes.push({ title: '', exams: [] });
  }
  classCount++;
  calculateAverage(classCount - 1);
  saveData();
  classCount++;
  calculateAverage(classCount - 1);
  saveData();
}

function createExamRow(classIndex, examData = {}) {
  const title = examData.title || '';
  const grade = examData.grade || '';
  const type = examData.type || 'raw';
  const outOf = examData.outOf || 10;
  const weight = examData.weight || '';

  return `
    <tr>
      <td><input type="text" placeholder="e.g. Midterm" value="${title}" oninput="saveData()" /></td>
      <td><input type="text" placeholder="e.g. 8.5 or 85%" value="${grade}" onchange="calculateAverage(${classIndex}); saveData();" /></td>
      <td>
        <select onchange="calculateAverage(${classIndex}); saveData();">
          <option value="raw" ${type === 'raw' ? 'selected' : ''}>Number</option>
          <option value="percent" ${type === 'percent' ? 'selected' : ''}>%</option>
        </select>
      </td>
      <td><input type="number" value="${outOf}" onchange="calculateAverage(${classIndex}); saveData();" /></td>
      <td><input type="number" min="0" max="100" value="${weight}" onchange="calculateAverage(${classIndex}); saveData();" /></td>
    </tr>
  `;
}

function addExamRow(classIndex) {
  const tbody = document.getElementById(`class-${classIndex}-table`);
  tbody.insertAdjacentHTML('beforeend', createExamRow(classIndex));
  saveData();
}

function calculateAverage(classIndex) {
  const rows = document.querySelectorAll(`div[data-index='${classIndex}'] tbody tr`);
  let totalWeight = 0;
  let weightedSum = 0;

  rows.forEach(row => {
    const inputs = row.querySelectorAll('input');
    const gradeInput = inputs[1].value.trim();
    const type = row.querySelector('select').value;
    const outOf = parseFloat(inputs[2].value);
    const weight = parseFloat(inputs[3].value);

    let grade = 0;
    if (type === 'percent') {
      grade = parseFloat(gradeInput.replace('%', ''));
    } else {
      grade = parseFloat(gradeInput);
    }

    if (!isNaN(grade) && !isNaN(outOf) && !isNaN(weight)) {
      const normalizedGrade = (type === 'percent') ? grade : (grade / outOf) * 100;
      weightedSum += normalizedGrade * (weight / 100);
      totalWeight += weight;
    }
  });

  const finalAverage = totalWeight ? (weightedSum / (totalWeight / 100)) : 0;
  document.getElementById(`average-${classIndex}`).innerText = finalAverage.toFixed(2);
}

function saveData() {
  const data = {
    mode,
    students
  };
  localStorage.setItem('gradeTrackerData', JSON.stringify(data));
}

function loadData() {
  const saved = localStorage.getItem('gradeTrackerData');
  if (!saved) return;
  const data = JSON.parse(saved);
  mode = data.mode || 'student';
  students = data.students || [];
  setMode(mode);
  renderStudentList();
}

function resetAll() {
  if (confirm('Are you sure you want to delete all data?')) {
    localStorage.removeItem('gradeTrackerData');
    location.reload();
  }
}
